package com.example.kf7008assignment;

//interface for swipe pull down layout refresh, whatever the hell its called.
//Composition over inheritance
public interface ISwipeRefresh
{
    void SwipeRefreshLayout();
}
