package com.example.kf7008assignment;

public interface IFoodLogPresenter
{
}
