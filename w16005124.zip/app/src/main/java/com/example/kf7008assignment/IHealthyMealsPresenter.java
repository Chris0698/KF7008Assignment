package com.example.kf7008assignment;

public interface IHealthyMealsPresenter
{
    void AddFoodItem(FoodItem foodItem);
}
