package com.example.kf7008assignment;

public interface IMyDevicePresenter
{
    void SetDeviceName(String name);

    void SetDeviceAddress(String address);

    void SetButtonText(String text);
}
