package com.example.kf7008assignment;

public interface IMyGoalsPresenter
{
    void SetStepsTextView(String value);

    void SetSleepTextView(String value);

    void SetCaloriesTextView(String value);

    void SetStepsGoalTextView(String goalCount);

    void SetSleepGoalTextView(String goalCount);

    void SetCaloriesGoalTextView(String goalCount);
}
